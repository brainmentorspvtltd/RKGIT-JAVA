package com.brainmentors.gaming;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;

import com.brainmentors.gaming.sprites.Enemy;
import com.brainmentors.gaming.sprites.Player;
import com.brainmentors.gaming.sprites.Sprite;

public class Board extends JPanel{
	
	// Constructor (Initlalize)
	BufferedImage bi ;
	Player player ;
	//Enemy enemy;
	Enemy enemies[] ;
	int x[] = new int[10];
	Board() throws Exception{
		//Sprite sprite = new Sprite();
		setSize(1000,600); // Board Size Set
		bi = ImageIO.read(Board.class.getResource("game-bg.jpeg")); // Image Read
		player = new Player();
		enemies = new Enemy[3]; // all enemies are null
		loadEnemies();
		setFocusable(true);
		bindEvents();
		gameLoop();
		
	
	}
	
//	boolean isCollide(){
//		
//	}
	
	
	void bindEvents() {
		this.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				//System.out.println("KeyPress.....");
				if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
					player.move();
				}
				
			}
		});
	}
	
	void gameLoop(){
		
		// Delay
		Timer timer = new Timer(50,new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				repaint();
				
				
			}
		});
		timer.start();
	}
	
	void loadEnemies() throws IOException {
		int x = 250;
		final int GAP = 250;
		int speed = 2;
		for (int i = 0 ; i<enemies.length; i++) {
			enemies[i] = new Enemy(x, speed);
			speed = speed + 4;
			x = x + GAP;
			
		}
	}
	
	void printEnemies(Graphics pen) {
		for(Enemy e : enemies) {
			e.draw(pen);
			e.move();
		}
	}
	
	// Painting on Board
	@Override
	public void  paintComponent(Graphics pen){
//		pen.setColor(Color.RED);
//		pen.fillRect(10, 50, 70, 50);
//		pen.drawRect(20, 100, 100, 100);
//		pen.drawOval(300, 50, 100, 100);
//		pen.setFont(new Font("times", Font.BOLD, 50));
//		pen.drawString("Game 2022", 300, 300);
		pen.drawImage(bi,0,0,1000,600, null);
		player.draw(pen);
		printEnemies(pen);
		//enemy.draw(pen);
		
	}

}

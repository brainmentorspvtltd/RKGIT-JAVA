package com.brainmentors.gaming.sprites;

import java.io.IOException;

import javax.imageio.ImageIO;

import com.brainmentors.gaming.Board;

public class Player extends Sprite{
	public Player() throws IOException{
		x= 20;
		y = 400;
		w = 100;
		h = 100;
		speed = 10;
		bi = ImageIO.read(Player.class.getResource("player.gif"));
	}
	@Override
	public void move() {
		x = x + speed;
	}
	
	
}

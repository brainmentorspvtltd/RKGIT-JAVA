package com.brainmentors.gaming;

public interface Constants {
	int BOARD_HEIGHT = 700; // public static final int BOARD_HEIGHT  = 700
	int BOARD_WIDTH = 1200;
	int MAX_ENEMY = 3;
	int GRAVITY = 1;
	int FLOOR = 200;
	int STAND = 1;
	int WALK = 2;
	int PUNCH = 3;
	int KICK = 4;
	int MAX_POWER = 10;
}

package com.brainmentors.gaming;

import java.io.File;

import jaco.mp3.player.MP3Player;

public class Sound {
	MP3Player mp3 ;
	public void play() {
		mp3 = new MP3Player(new File("/Users/amitsrivastava/Downloads/file_example_MP3_700KB.mp3"));
		mp3.play();
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mp3.stop();
	}
	public static void main(String[] args) {
		Sound s = new Sound();
		s.play();
		
	}

}

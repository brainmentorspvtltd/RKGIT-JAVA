package com.brainmentors.gaming.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import com.brainmentors.gaming.Board;
import com.brainmentors.gaming.Constants;

public class Player extends Sprite implements Constants{
	int force ;
	boolean isJump ;
	private ArrayList<Bullet> bullets = new ArrayList<>();
	BufferedImage stand[] = new BufferedImage[4];
	BufferedImage walk[] = new BufferedImage[4];
	BufferedImage punch[] = new BufferedImage[4];
	BufferedImage kick[] = new BufferedImage[4];
	final int SIZE = 100;
	final int SIZE_W = 70;
	int currentMove = STAND;
	int power;
	BufferedImage currentDraw[] = new BufferedImage[4];
	
	
	
	public int getPower() {
		return power;
	}

	public void setPower(int power) {
		this.power = power;
	}

	public void setCurrentMove(int currentMove) {
		this.currentMove = currentMove;
		moveIndex = 0;
	}
	
	public void loadStand() {
		stand[0] = bi.getSubimage(39, 117, SIZE_W, SIZE);
		stand[1] = bi.getSubimage(109, 117, SIZE_W, SIZE);
		stand[2] = bi.getSubimage(185, 117, SIZE_W, SIZE);
		stand[3] = bi.getSubimage(269, 117, SIZE_W, SIZE);
	}
	
	public void loadWalk() {
		
		walk[0] = bi.getSubimage(62, 234, SIZE_W, SIZE);
		walk[1] = bi.getSubimage(143, 234, SIZE_W, SIZE);
		walk[2] = bi.getSubimage(224, 234, SIZE_W, SIZE);
		walk[3] = bi.getSubimage(300, 234, SIZE_W, SIZE);
	}
	
	public void loadPunch() {
		punch[0] = bi.getSubimage(257, 699, SIZE_W, SIZE);
		punch[1] = bi.getSubimage(344, 699, SIZE_W, SIZE);
		punch[2] = bi.getSubimage(433, 699, SIZE_W, SIZE);
		punch[3] = bi.getSubimage(524, 699, SIZE_W+43, SIZE);
	}
	
	public void loadKick() {
		kick[0] = bi.getSubimage(38, 1045, SIZE_W, SIZE);
		kick[1] = bi.getSubimage(120, 1045, SIZE_W, SIZE);
		kick[2] = bi.getSubimage(200, 1045, SIZE_W+50, SIZE);
		kick[3] = bi.getSubimage(332, 1045, SIZE_W, SIZE);
	}
	
	int moveIndex = 0;
	public void frameImage() {
		moveIndex++;
		if(moveIndex>3) {
			moveIndex=0;
			currentMove = STAND;
		}
	}
	@Override
	public void draw(Graphics pen) {
		
		if(currentMove == STAND) {
			currentDraw = stand;
		}
		else
		if(currentMove == WALK) {
			currentDraw = stand;
		}
		else
			if(currentMove == PUNCH) {
				currentDraw = punch;
			}
			else
				if(currentMove == KICK) {
					currentDraw = kick;
				}
		frameImage();
		pen.drawImage(currentDraw[moveIndex], x,y,w,h,null);
	}
	public Player() throws IOException{
		x= 20;
		h = 100;
		y = BOARD_HEIGHT -FLOOR -h;
		w = 120;
		isJump = false;
		power = MAX_POWER;	
		speed = 10;
		bi = ImageIO.read(Player.class.getResource("ryu.gif"));
		loadStand();
		loadWalk();
		loadPunch();
		loadKick();
	}
	
	public ArrayList<Bullet> getBullets(){
		return bullets;
	}
	
	public void addBullet(int x, int y) {
		bullets.add(new Bullet(x,y));
	}
	
	public void jump() {
		if(!isJump) {
		force = -20;
		y = y + force;
			isJump = true;
		}
	}
	
	public void fall() {
		if(y>=BOARD_HEIGHT-FLOOR-h) {
			isJump = false;
			return ;
		}
		force  = force + GRAVITY;
		y = y + force;
	}
	
	@Override
	public void move() {
		x = x + speed;
	}
	public boolean outOfScreen() {
		if(x>BOARD_WIDTH) {
			return true;
		}
		return false;
	}
	
	
}

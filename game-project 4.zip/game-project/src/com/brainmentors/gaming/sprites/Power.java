package com.brainmentors.gaming.sprites;

import java.awt.Color;
import java.awt.Graphics;

import com.brainmentors.gaming.Constants;

public class Power extends Sprite implements Constants {
	Color color;
	boolean isCollide = false;
	
	
	public boolean isCollide() {
		return isCollide;
	}

	public void setCollide(boolean isCollide) {
		this.isCollide = isCollide;
	}

	public Power(Color color){
		x = 20;
		y = 10;
		w = 200;
		h = 50;
		this.color = color;
		
	}

	@Override
	public void move() {
		// TODO Auto-generated method stub
		
	}
	
	
	public void draw(Graphics pen, int pow) {
		if(isCollide) {
		if(color == Color.GREEN) {
			int val = (int)(this.w * 0.20);
			w = w - val;
		}
		isCollide = false;
		}
		pen.setColor(color);
		pen.fillRect(x,y,w,h);
	}

}

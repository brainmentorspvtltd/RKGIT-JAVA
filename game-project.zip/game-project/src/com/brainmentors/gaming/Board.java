package com.brainmentors.gaming;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import com.brainmentors.gaming.sprites.Enemy;
import com.brainmentors.gaming.sprites.Player;

public class Board extends JPanel{
	
	// Constructor (Initlalize)
	BufferedImage bi ;
	Player player ;
	//Enemy enemy;
	Enemy enemies[] ;
	int x[] = new int[10];
	Board() throws Exception{
		setSize(1000,600); // Board Size Set
		bi = ImageIO.read(Board.class.getResource("game-bg.jpeg")); // Image Read
		player = new Player();
		enemies = new Enemy[3]; // all enemies are null
		loadEnemies();
	
	}
	
	void loadEnemies() throws IOException {
		int x = 150;
		final int GAP = 200;
		for (int i = 0 ; i<enemies.length; i++) {
			enemies[i] = new Enemy(x);
			x = x + GAP;
			
		}
	}
	
	void printEnemies(Graphics pen) {
		for(Enemy e : enemies) {
			e.draw(pen);
		}
	}
	
	// Painting on Board
	@Override
	public void  paintComponent(Graphics pen){
//		pen.setColor(Color.RED);
//		pen.fillRect(10, 50, 70, 50);
//		pen.drawRect(20, 100, 100, 100);
//		pen.drawOval(300, 50, 100, 100);
//		pen.setFont(new Font("times", Font.BOLD, 50));
//		pen.drawString("Game 2022", 300, 300);
		pen.drawImage(bi,0,0,1000,600, null);
		player.draw(pen);
		printEnemies(pen);
		//enemy.draw(pen);
		
	}

}

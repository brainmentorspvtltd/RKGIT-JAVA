package com.brainmentors.gaming.sprites;

import java.io.IOException;

import javax.imageio.ImageIO;

public class Enemy extends Sprite {
	public Enemy(int x) throws IOException{
		this.x= x;
		y = 50;
		w = 100;
		h = 100;
		speed = 4;
		bi = ImageIO.read(Enemy.class.getResource("spider.png"));
	}
}

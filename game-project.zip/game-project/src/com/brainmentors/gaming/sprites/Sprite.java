package com.brainmentors.gaming.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Sprite {
	
	int x;
	int y;
	int w ;
	int h;
	BufferedImage bi;
	int speed;
	
	public void draw(Graphics pen){
		pen.drawImage(bi, x,y,w,h,null);
	}

}

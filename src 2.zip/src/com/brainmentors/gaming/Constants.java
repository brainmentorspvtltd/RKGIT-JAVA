package com.brainmentors.gaming;

public interface Constants {
	int BOARD_HEIGHT = 900; // public static final int BOARD_HEIGHT  = 700
	int BOARD_WIDTH = 1200;
	int MAX_ENEMY = 3;
	int GRAVITY = 1;
	int FLOOR = 100;
}

package com.brainmentors.gaming.sprites;

import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import com.brainmentors.gaming.Board;
import com.brainmentors.gaming.Constants;

public class Player extends Sprite implements Constants{
	int force ;
	boolean isJump ;
	private ArrayList<Bullet> bullets = new ArrayList<>();
	public Player() throws IOException{
		x= 20;
		h = 100;
		y = BOARD_HEIGHT -FLOOR -h;
		w = 100;
		isJump = false;
		
		speed = 10;
		bi = ImageIO.read(Player.class.getResource("player.gif"));
	}
	
	public ArrayList<Bullet> getBullets(){
		return bullets;
	}
	
	public void addBullet(int x, int y) {
		bullets.add(new Bullet(x,y));
	}
	
	public void jump() {
		if(!isJump) {
		force = -20;
		y = y + force;
			isJump = true;
		}
	}
	
	public void fall() {
		if(y>=BOARD_HEIGHT-FLOOR-h) {
			isJump = false;
			return ;
		}
		force  = force + GRAVITY;
		y = y + force;
	}
	
	@Override
	public void move() {
		x = x + speed;
	}
	public boolean outOfScreen() {
		if(x>BOARD_WIDTH) {
			return true;
		}
		return false;
	}
	
	
}

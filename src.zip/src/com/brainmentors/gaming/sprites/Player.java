package com.brainmentors.gaming.sprites;

public class Player {

}
